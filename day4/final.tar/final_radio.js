



// Initial module
var app = require('express')();
var server = require('http').Server(app);
var io = require('socket.io')(server);

var fs = require('fs');
var exec = require('child_process').exec;
var spawn = require('child_process').spawn;
var rsj = require('rsj');
var oled =  require('oled-spi');
var font = require('oled-font-5x7');

// Global Variables
var usb_list = [];
var volume = 100;
var current;
var total;
var random = false;
var SRC_DIR = '/home/pi/pie/day4/';
var MEDIA_DIR = '/media/pi/AUDIO/';

// For Server Running
app.get('/', function(req, res){
	res.sendFile(__dirname + '/final_radio.html');
});

server.listen(8080, function(){
	console.log('Server is running on Your Raspberry Pi');
});

// Event for socket.io
io.on('connection', function(socket){
	console.log('Connect is started');
	
	socket.on('play', function(item){
		console.log('Play: '+ item.title + ', ' + item.file);
		random = false;
		playUSB(item.file);			
	});
	
	socket.on('stop', function(){
		console.log('Stop');
		random = false;
    exec('pkill mplayer');
	});
	
	socket.on ('vol_up', function(){
		console.log('Vol up');
		setVolume('up');
	});

	socket.on ('vol_down', function(){
		console.log('Vol down');
		setVolume('down');
	});
	
	socket.on ('random', function(){
		console.log('random');
		random = true;
		playRandomUSB();
	});

	socket.on ('radio', function(data){
		playRadio(data);
	});

 //update news when socket.io connected
	updateNews();
});

// For Oled Display
var opts = {
	width: 128,
	height: 64,
	dcPin: 23,
	rstPin: 24
};

var oled = new oled(opts);

oled.begin(function(){
	oled.clearDisplay();
	oled.setCursor(1, 1);
	oled.writeString(font, 2, 'IoT Box', 1, true);

	setInterval(function(){
		exec('date +%H:%M:%S', function(error, stdout, stderr){
		  oled.setCursor(1, 32);
			oled.writeString(font, 2, stdout, 1, true);
		});
	}, 1000); 
});

// Main Code
setInterval(function(){
	exec('find ' + MEDIA_DIR+ ' -name "*.mp3"', function(err, stdout){
    usb_list = [];
	  var list = stdout.split('\n');
	  usb_list = usb_list.concat(list.splice(0, list.length-1));
    //console.log(usb_list);
	  io.sockets.emit('usb_list', usb_list);
  });
	console.log('python ' + SRC_DIR + 'facedetect.py')
	exec('python ' + SRC_DIR + 'facedetect.py', function(err, stdout, stderr){
		if(!stdout){
			return;
		}

		var pic;
		if(stdout.indexOf('not') > -1) {
			pic = SRC_DIR + 'no_face.png';
		}
		else {
			pic = SRC_DIR + 'face.jpg';
		}
					
		fs.readFile(pic, function(err, data){
			if(!err){
				var buffer = new Buffer(data).toString('base64');
				console.log(pic);
				io.sockets.emit('pic', buffer);
			}
		});
	});

	var date = new Date();
	if((date.getMinutes() == 0) && (date.getSeconds() == 0))
		updateNews();
}, 5000);

// Functions
function updateNews(){
	var news = [];
	rsj.r2j('http://fs.jtbc.joins.com/RSS/newsflash.xml', function(json){
		var items = JSON.parse(json);

		for(var i = 0; i < 5;i++)
			news[i] = items[i].title;
		
		io.sockets.emit('news', news);
	});
}

function playUSB(item){
	exec('pkill mplayer', function(){
		console.log('Playing : ' + item);
		io.sockets.emit('music', item.split(MEDIA_DIR)[1]);

		var ps = spawn('mplayer',[item]);

		ps.stderr.on('data', function(data){
			var progress = data.toString('utf8');
			if(progress && progress.indexOf('of') > -1){

				var token = progress.split(' of ');

				current = token[0].split(' ').slice(-2)[0];
				total = token[1].split(' ')[0];
				io.sockets.emit('music_time', {current:current, total: total});
			}
		});

		ps.on('close', function(code){
			console.log('close');
			if (random == true){
				setTimeout(function(){
					playRandomUSB();
				}, 1000);
			}
		});        
	});
}

function playRandomUSB(){
  exec('pkill mplayer', function(){
		var file_count = 0;
		exec('find ' + MEDIA_DIR + ' -name "*.mp3"|wc -l', function(err, stdout){
			if(usb_list == false || err || parseInt(stdout) == 0) {
				console.log('No Music file');
			}
			else {
			  file_count = parseInt(stdout);
				playUSB(usb_list[Math.floor(Math.random() * file_count)]);
			}
		}); 
	});
}

function playRadio(data){
    exec('pkill mplayer', function(){
			exec('mplayer ' + data);
		});				
}

function setVolume(vol){
    if(vol == 'up'){
        if(volume < 100){
            volume += 5;
        }
    } else {
        if(volume > 0){
            volume -= 5;
        }
    }
    
    console.log('VOLUME: ' + volume);
    exec('amixer sset PCM ' + volume + '%'); 
}

